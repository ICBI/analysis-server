This directoy is used to hold temporary files that are generated
while the analysis server executes.  For example, Rserv uses
this directory to write temporary image files that are generated
for the hierarchical clusering report.